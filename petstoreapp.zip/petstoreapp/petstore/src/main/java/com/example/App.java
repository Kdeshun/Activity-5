package com.example;

import java.util.ArrayList;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        System.out.println("Welcome to pet world!");

        PetStoreDataAccessObject dao = new PetStoreDataAccessObject();
        Scanner scanner = new Scanner(System.in);

        int choice = -1;
        while (choice != 0) {
            System.out.println("Please choose an option:");
            System.out.println("1) Show all pets");
            System.out.println("2) Show one pet");
            System.out.println("3) Search for a pet");
            System.out.println("4) Add a pet");
            System.out.println("5) Delete a pet");
            System.out.println("6) Update a pet");
            System.out.println("0) Quit");

            try {
                choice = Integer.parseInt(scanner.nextLine());

                switch (choice) {
                    case 1:
                        System.out.println("========Show all pets=========");
                        ArrayList<Pet> allPets = dao.getAllPets();
                        for (Pet pet : allPets) {
                            System.out.println(pet);
                        }
                        break;
                    case 2:
                        System.out.println("========Show one pet=========");
                        System.out.println("Enter the ID of the pet:");
                        int petId = Integer.parseInt(scanner.nextLine());
                        Pet onePet = dao.getById(petId);
                        System.out.println(onePet);
                        break;
                    case 3:
                        System.out.println("========Search for 'e' in pet names:========");
                        System.out.println("Enter the search term:");
                        String searchTerm = scanner.nextLine();
                        ArrayList<Pet> foundPets = dao.searchForMany(searchTerm);
                        System.out.println("These are the " + foundPets.size() + " pets found:");
                        for (Pet pet : foundPets) {
                            System.out.println(pet);
                        }
                        break;
                    case 4:
                        System.out.println(" ======  Add a new pet ========");
                        Pet newPet = new Pet();
                        System.out.println("Enter ID:");
                        newPet.setId(Integer.parseInt(scanner.nextLine()));
                        System.out.println("Enter name:");
                        newPet.setName(scanner.nextLine());
                        System.out.println("Enter description:");
                        newPet.setDescription(scanner.nextLine());
                        System.out.println("Enter price:");
                        newPet.setPrice(Double.parseDouble(scanner.nextLine()));
                        System.out.println("Enter category ID:");
                        newPet.setCategoryId(Integer.parseInt(scanner.nextLine()));
                        int addResult = dao.addOne(newPet);
                        System.out.println(addResult + " items inserted");
                        break;
                    case 5:
                        System.out.println("======= Delete a pet =======");
                        System.out.println("Enter the ID of the pet to delete:");
                        int deleteId = Integer.parseInt(scanner.nextLine());
                        Pet deletePet = new Pet();
                        deletePet.setId(deleteId);
                        int deleteResult = dao.deleteOne(deletePet);
                        System.out.println(deleteResult + " items deleted");
                        break;
                    case 6:
                        System.out.println("======= Update a pet =======");
                        System.out.println("Enter the ID of the pet to update:");
                        int updateId = Integer.parseInt(scanner.nextLine());
                        Pet updatePet = new Pet();
                        updatePet.setId(updateId);
                        System.out.println("Enter the new name:");
                        updatePet.setName(scanner.nextLine());
                        System.out.println("Enter the new description:");
                        updatePet.setDescription(scanner.nextLine());
                        System.out.println("Enter the new price:");
                        updatePet.setPrice(Double.parseDouble(scanner.nextLine()));
                        System.out.println("Enter the new category ID:");
                        updatePet.setCategoryId(Integer.parseInt(scanner.nextLine()));
                        int updateResult = dao.updateOne(updatePet);
                        System.out.println(updateResult + " items updated");
                        break;
                    case 0:
                        System.out.println("Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                        break;
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }

        scanner.close();
    }
}
