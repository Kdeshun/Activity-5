package com.example;

import java.sql.*;
import java.util.ArrayList;

public class PetStoreDataAccessObject {
    static final String DATABASE_URL = "jdbc:mysql://localhost/my_pet_store";
    static final String USERNAME = "root";
    static final String PASSWORD = "";

    public ArrayList<Pet> getAllPets() {
        // create an empty list of Pets. Will be appended and returned.
        ArrayList<Pet> returnThese = new ArrayList<>();
        
        // Open a connection
        try (Connection conn = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD)) {
            // make connection
            Statement stmt = conn.createStatement();
            String sqlString = "SELECT ID, NAME, PRICE, DESCRIPTION,CATEGORYID FROM Pets";
            
            // execute query is for SELECT statements. There are other execute commands.
            // See documentation at https://docs.oracle.com/javase/tutorial/jdbc/basics/processingsqlstatements.html
            ResultSet resultSet = stmt.executeQuery(sqlString);
            
            // loop through each item in the result set
            while (resultSet.next()) {
                // for each row in the result set, create a new pet
                Pet p = new Pet();
                p.setId(resultSet.getInt("ID"));
                p.setName(resultSet.getString("NAME"));
                p.setPrice(resultSet.getDouble("PRICE"));
                p.setDescription(resultSet.getString("DESCRIPTION"));
                p.setCategoryId(resultSet.getInt("CATEGORYID"));
                
                // add another pet to the return list
                returnThese.add(p);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        
        // returnThese should contain multiple pets.
        return returnThese;
    }

    // fetch one pet given its Id number
    public Pet getById(int id) {
    ArrayList<Pet> returnThese = new ArrayList<>();

    // Open a connection
    try (Connection conn = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD)) {
        // Id is a placeholder.
        String sqlString = "SELECT ID, NAME, PRICE, DESCRIPTION, CATEGORYID FROM Pets WHERE Id = ?";
        // prepared statements are used for security. Prevent SQL injection attacks.
        PreparedStatement preparedStatement = conn.prepareStatement(sqlString);
        // associate the first (and only) question mark with the Id number we are trying to fetch.
        // id is from method's parameter.
        preparedStatement.setInt(1, id);

        ResultSet rs = preparedStatement.executeQuery();
        while (rs.next()) {
            Pet p = new Pet();
            p.setId(rs.getInt("ID"));
            p.setName(rs.getString("NAME"));
            p.setPrice(rs.getDouble("PRICE"));
            p.setDescription(rs.getString("DESCRIPTION"));
            p.setCategoryId(rs.getInt("CATEGORYID"));

            returnThese.add(p);
        }
    } catch (SQLException e) {
        System.out.println(e.getMessage());
    }

    // return the first element in the list
    if (returnThese.size() > 0)
        return returnThese.get(0);

    return null;
}

    // Fetch all pets whose name matches the search parameter
    public ArrayList<Pet> searchForMany(String searchTerm) {
    ArrayList<Pet> returnThese = new ArrayList<>();

    // Open a connection
    try (Connection conn = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD)) {
        String sqlString = "SELECT ID, NAME, PRICE, DESCRIPTION, CATEGORYID FROM Pets WHERE NAME LIKE ?";
        PreparedStatement preparedStatement = conn.prepareStatement(sqlString);
        
        // Add wildcard chars before and after the search term to allow for partial matches
        preparedStatement.setString(1, "%" + searchTerm + "%");

        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            Pet p = new Pet();
            p.setId(resultSet.getInt("ID"));
            p.setName(resultSet.getString("NAME"));
            p.setPrice(resultSet.getDouble("PRICE"));
            p.setDescription(resultSet.getString("DESCRIPTION"));
            p.setCategoryId(resultSet.getInt("CATEGORYID"));

            returnThese.add(p);
        }
    } catch (SQLException e) {
        System.out.println(e.getMessage());
    }

    return returnThese;
}

    // Add a new pet to the database
    public int addOne(Pet newPet) {
    try {
        Connection conn = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
        String updateString = "INSERT INTO PETS (ID, NAME, DESCRIPTION, PRICE, CATEGORYID) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement preparedStatement = conn.prepareStatement(updateString);
        
        // Set parameters for the prepared statement
        preparedStatement.setInt(1, newPet.getId());
        preparedStatement.setString(2, newPet.getName());
        preparedStatement.setString(3, newPet.getDescription());
        preparedStatement.setDouble(4, newPet.getPrice());
        preparedStatement.setInt(5, newPet.getCategoryId());
        
        // executeUpdate returns the number of rows affected by the query
        int updates = preparedStatement.executeUpdate();
        
        return updates;
    } catch (SQLException e) {
        System.out.println(e.getMessage());
    }
    return 0;
}

    public int updateOne(Pet newPet) {
    try (Connection conn = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD)) {
        String updateString = "UPDATE PETS SET NAME = ?, PRICE = ?, DESCRIPTION = ?, CATEGORYID = ? WHERE ID = ?";
        PreparedStatement preparedStatement = conn.prepareStatement(updateString);
        
        // Set parameters for the prepared statement
        preparedStatement.setString(1, newPet.getName());
        preparedStatement.setDouble(2, newPet.getPrice());
        preparedStatement.setString(3, newPet.getDescription());
        preparedStatement.setInt(4, newPet.getCategoryId());
        preparedStatement.setInt(5, newPet.getId());
        
        // executeUpdate returns the number of rows affected by the query
        int updates = preparedStatement.executeUpdate();
        
        return updates;
    } catch (SQLException e) {
        System.out.println(e.getMessage());
    }
    return 0;
}

    public int deleteOne(Pet deletePet) {
        try (Connection conn = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD)) {
            String deleteString = "DELETE FROM PETS WHERE ID = ?";
            PreparedStatement preparedStatement = conn.prepareStatement(deleteString);
            
            // Set parameter for the prepared statement
            preparedStatement.setInt(1, deletePet.getId());
            
            // executeUpdate returns the number of rows affected by the query
            int deletes = preparedStatement.executeUpdate();
            
            return deletes;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return 0;
    }

}
